import { useState } from 'react';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import UploadSection from './components/UploadSection';
import ProcessingModal from './components/ProcessingModal';
import CuePointsDisplay from './components/CuePointsDisplay';
import TechStack from './components/TechStack';
import About from './components/About';
import Footer from './components/Footer';

function App() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const scrollToUpload = () => {
    document.getElementById('upload')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleGenerate = () => {
    setIsProcessing(true);
  };

  const handleProcessingComplete = () => {
    setIsProcessing(false);
    setShowResults(true);
    setTimeout(() => {
      document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' });
    }, 300);
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <Hero onUploadClick={scrollToUpload} onGenerateClick={scrollToUpload} />
      <HowItWorks />
      <UploadSection onGenerate={handleGenerate} />
      {showResults && <CuePointsDisplay />}
      <TechStack />
      <About />
      <Footer />
      <ProcessingModal isOpen={isProcessing} onComplete={handleProcessingComplete} />
    </div>
  );
}

export default App;
