import { Target, Zap, Clock, TrendingUp } from 'lucide-react';

const benefits = [
  {
    icon: Clock,
    title: '10x Faster Workflow',
    description: 'What takes hours manually now completes in seconds'
  },
  {
    icon: Target,
    title: 'Precision Accuracy',
    description: 'AI-powered detection with 99% beat-perfect alignment'
  },
  {
    icon: Zap,
    title: 'Instant Export',
    description: 'Ready-to-use VirtualDJ XML files, no manual editing needed'
  },
  {
    icon: TrendingUp,
    title: 'Consistent Quality',
    description: 'Professional-grade cue points every time, guaranteed'
  }
];

export default function About() {
  return (
    <section className="py-24 px-6 bg-gradient-to-b from-black via-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-5xl font-bold text-white mb-6">
              The Future of DJ Preparation
            </h2>
            <div className="space-y-6 text-gray-300 text-lg leading-relaxed">
              <p>
                <span className="text-white font-semibold">AUTOCLUE</span> revolutionizes how DJs
                prepare their music libraries. Traditional cue point placement is tedious,
                time-consuming, and inconsistent.
              </p>
              <p>
                Our GenAI-powered solution analyzes your tracks with the precision of a trained
                audio engineer, identifying key moments like drops, build-ups, and transitions
                with superhuman accuracy.
              </p>
              <p>
                Powered by Google's Gemini AI and advanced audio analysis libraries, AUTOCLUE
                understands musical structure at a deep level, delivering professional results
                that match or exceed manual placement.
              </p>
            </div>

            <div className="mt-12 p-8 bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/30 rounded-2xl">
              <h3 className="text-2xl font-bold text-white mb-4">The Problem</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Manual cue point placement takes 10-15 minutes per track</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Inconsistent quality and missed transitions</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Repetitive, mind-numbing work that kills creativity</span>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 mb-8">
              <h3 className="text-3xl font-bold text-white mb-8">Benefits for DJs</h3>
              <div className="space-y-6">
                {benefits.map((benefit, index) => {
                  const Icon = benefit.icon;
                  return (
                    <div
                      key={index}
                      className="flex gap-4 p-6 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-2xl hover:bg-white/10 hover:border-blue-500/30 transition-all duration-300"
                    >
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <h4 className="text-xl font-semibold text-white mb-2">
                          {benefit.title}
                        </h4>
                        <p className="text-gray-400">{benefit.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-white mb-4">The Solution</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Process entire libraries in minutes, not weeks</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Professional-grade precision every single time</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Focus on creativity, not tedious preparation work</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
