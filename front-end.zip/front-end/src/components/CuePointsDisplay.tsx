import { useEffect, useRef, useState } from 'react';
import { Download, Clock, Activity, Zap } from 'lucide-react';
import { mockCuePoints, mockTrackInfo, CuePoint } from '../data/mockCuePoints';

const cueTypeColors = {
  intro: 'from-green-500 to-emerald-600',
  verse: 'from-blue-500 to-cyan-600',
  buildup: 'from-yellow-500 to-orange-600',
  drop: 'from-red-500 to-pink-600',
  chorus: 'from-purple-500 to-violet-600',
  breakdown: 'from-indigo-500 to-blue-600',
  outro: 'from-gray-500 to-slate-600'
};

const cueTypeIcons = {
  intro: '▶',
  verse: '♪',
  buildup: '↗',
  drop: '⚡',
  chorus: '★',
  breakdown: '↘',
  outro: '■'
};

export default function CuePointsDisplay() {
  const [cuePoints, setCuePoints] = useState<CuePoint[]>(mockCuePoints);
  const [trackInfo, setTrackInfo] = useState(mockTrackInfo);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);

  const audioSrc = `/${trackInfo.fileName}`;

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onTime = () => setCurrentTime(a.currentTime);
    a.addEventListener('play', onPlay);
    a.addEventListener('pause', onPause);
    a.addEventListener('timeupdate', onTime);
    return () => {
      a.removeEventListener('play', onPlay);
      a.removeEventListener('pause', onPause);
      a.removeEventListener('timeupdate', onTime);
    };
  }, [audioRef, trackInfo.fileName]);

  const togglePlay = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      a.play();
    } else {
      a.pause();
    }
  };

  const seekTo = (seconds: number | null) => {
    const a = audioRef.current;
    if (!a || seconds == null) return;
    a.currentTime = Math.max(0, Math.min(seconds, a.duration || seconds));
    a.play();
  };

  useEffect(() => {
    let mounted = true;
    fetch('/validated_cues.json')
      .then((res) => {
        if (!res.ok) throw new Error('no validated file');
        return res.json();
      })
      .then((data) => {
        if (!mounted) return;
        // Expecting either an array of cue points or an object { cues: [], track: {} }
        if (Array.isArray(data)) {
          setCuePoints(data);
        } else if (data && Array.isArray(data.cues)) {
          setCuePoints(data.cues);
          if (data.track) setTrackInfo(data.track);
        } else {
          // fallback: keep mock
          console.warn('validated_cues.json format not recognized, using mock data');
        }
      })
      .catch(() => {
        // keep mock data on error
      });

    return () => {
      mounted = false;
    };
  }, []);

  const downloadJSON = () => {
    // include normalized times, timeSource and normalizedConfidence in exported JSON
    const payload = normalizedCuePoints.map(c => ({ ...c }));
    const dataStr = JSON.stringify(payload, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cue-points.json';
    link.click();
  };

  const downloadXML = () => {
    // Use normalizedTime when available; omit cues with unknown positions to avoid Pos="undefined"
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<VirtualDJ_Track>\n  <Cues>\n    ${normalizedCuePoints
      .filter(cue => (cue as any).normalizedTime != null)
      .map(cue => `<Cue Pos="${(cue as any).normalizedTime}" Name="${cue.label}" />`)
      .join('\n    ')}\n  </Cues>\n</VirtualDJ_Track>`;

    const dataBlob = new Blob([xml], { type: 'application/xml' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cue-points.xml';
    link.click();
  };

  // determine timeline length (seconds)
  const maxCueTime = cuePoints.reduce((max, c) => Math.max(max, c.timeInSeconds || 0), 0);
  const totalSeconds = Math.max(maxCueTime + 10, 60);

  const formatSeconds = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  };

  const isValidConfidence = (c: any) => typeof c === 'number' && !isNaN(c) && c >= 0 && c <= 1;

  const normalizeConfidence = (c: any): number | null => {
    if (c == null) return null;
    if (typeof c === 'string') {
      const parsed = parseFloat(c);
      if (isNaN(parsed)) return null;
      c = parsed;
    }
    if (typeof c === 'number') {
      if (isNaN(c)) return null;
      // If backend used 0..100 scale, normalize to 0..1
      if (c > 1) return Math.max(0, Math.min(1, c / 100));
      return Math.max(0, Math.min(1, c));
    }
    return null;
  };

  const parseTimestampToSeconds = (ts: any): number | null => {
    if (typeof ts !== 'string') return null;
    // accept H:MM:SS or M:SS formats
    const parts = ts.split(':').map(p => p.trim());
    if (parts.length === 2) {
      const m = parseInt(parts[0], 10);
      const s = parseFloat(parts[1]);
      if (!isNaN(m) && !isNaN(s)) return m * 60 + s;
    } else if (parts.length === 3) {
      const h = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const s = parseFloat(parts[2]);
      if (!isNaN(h) && !isNaN(m) && !isNaN(s)) return h * 3600 + m * 60 + s;
    }
    return null;
  };

  const isValidTime = (t: any) => typeof t === 'number' && !isNaN(t) && t >= 0;

  // Normalize cue times: accept `time` (seconds) or `timeInSeconds`, else try parsing `timestamp`.
  const normalizedCuePoints = cuePoints.map((c, idx) => {
    let normalizedTime: number | null = null;
    let timeSource: 'original' | 'parsed' | 'none' = 'none';

    // backend may provide `time` as seconds (float)
    if (isValidTime((c as any).time)) {
      normalizedTime = (c as any).time;
      timeSource = 'original';
    } else if (isValidTime((c as any).timeInSeconds)) {
      normalizedTime = (c as any).timeInSeconds;
      timeSource = 'original';
    } else {
      const parsed = parseTimestampToSeconds((c as any).timestamp);
      if (isValidTime(parsed)) {
        normalizedTime = parsed as number;
        timeSource = 'parsed';
      }
    }

    const normalizedConfidence = normalizeConfidence((c as any).confidence);

    // ensure id exists
    const id = (c as any).id ?? `${(c as any).label ?? 'cue'}-${idx}`;

    // ensure timestamp string exists (used by UI). If missing but we have normalizedTime, format it.
    const timestamp = (c as any).timestamp ?? (normalizedTime != null ? formatSeconds(normalizedTime) : (c as any).timestamp);

    // map backend types (hot/mix/marker) to UI types where possible; fallback to 'verse'
    const rawType = (c as any).type;
    const uiTypeMap: Record<string, string> = { hot: 'drop', mix: 'breakdown', marker: 'verse' };
    const uiType = (rawType && (uiTypeMap as any)[rawType]) || (rawType as any) || 'verse';

    return { ...c, id, timestamp, normalizedTime, timeSource, normalizedConfidence, type: uiType } as any;
  });

  // compute timeline total using normalized times when available
  const maxNormalized = normalizedCuePoints.reduce((max, c) => Math.max(max, (c as any).normalizedTime ?? 0), 0);
  const timelineSeconds = Math.max(maxNormalized + 10, totalSeconds);

  return (
    <section id="results" className="py-24 px-6 bg-gradient-to-b from-black via-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/30 rounded-full mb-6">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-400 font-medium">Processing Complete</span>
          </div>
          <h2 className="text-5xl font-bold text-white mb-4">Generated Cue Points</h2>
          <p className="text-xl text-gray-400">AI-detected moments perfectly aligned to your track</p>
        </div>

        <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 mb-12">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">{trackInfo.fileName}</h3>
              <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  {trackInfo.duration}
                </span>
                <span className="flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  {trackInfo.bpm} BPM
                </span>
                <span className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  {trackInfo.key}
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={downloadJSON}
                className="px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl font-medium text-white hover:bg-white/10 hover:border-blue-500/50 transition-all duration-300 flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                JSON
              </button>
              <button
                onClick={downloadXML}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-medium text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                VirtualDJ XML
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4 mb-6">
            <audio ref={audioRef} src={audioSrc} preload="metadata" />
            <button onClick={togglePlay} className="px-4 py-2 bg-white/5 rounded-md">
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <div className="text-sm text-gray-400">{formatSeconds(currentTime)} / {trackInfo.duration}</div>
            <div className="text-sm text-gray-400 ml-4">Click a cue to jump to position</div>
          </div>

          <div className="relative mb-12">
            <div className="relative h-24 bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 flex items-center">
                <div className="absolute inset-x-0 h-0.5 bg-white/20"></div>

                {normalizedCuePoints.filter(c => (c as any).normalizedTime !== null).map((cue) => {
                  const position = (((cue as any).normalizedTime as number) / timelineSeconds) * 100;
                  return (
                    <div
                      key={cue.id}
                      className="absolute group cursor-pointer"
                      style={{ left: `${position}%` }}
                      onClick={() => seekTo((cue as any).normalizedTime as number)}
                    >
                      <div className="relative">
                        <div className={`w-1 h-24 bg-gradient-to-b ${cueTypeColors[cue.type]} shadow-lg`}></div>
                        <div className="absolute -top-12 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                          <div className="bg-gray-900 border border-white/20 rounded-lg px-3 py-2 shadow-xl">
                            <p className="text-white font-medium text-sm">{cue.label}</p>
                            <p className="text-gray-400 text-xs">{cue.timestamp}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="absolute inset-x-0 bottom-0 h-12 flex items-center px-4">
                <div className="w-full flex justify-between text-xs text-gray-400">
                  <span>{formatSeconds(0)}</span>
                  <span>{formatSeconds(timelineSeconds / 2)}</span>
                  <span>{formatSeconds(timelineSeconds)}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {normalizedCuePoints.map((cue, index) => (
              <div
                key={cue.id}
                className="group relative bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:border-white/20 hover:bg-white/10 transition-all duration-300 hover:scale-105"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${cueTypeColors[cue.type]} rounded-xl flex items-center justify-center text-2xl shadow-lg`}>
                    {cueTypeIcons[cue.type]}
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">{cue.timestamp}</div>
                    <div className="text-xs text-gray-400 mt-1">
                      {(cue as any).normalizedConfidence != null ? `${Math.round(((cue as any).normalizedConfidence as number) * 100)}% confidence` : '—% confidence'}
                    </div>
                  </div>
                </div>

                <h4 className="text-lg font-semibold text-white mb-2">{cue.label}</h4>
                <div className="text-sm text-gray-400 mb-3">
                  {((cue as any).normalizedTime !== null)
                    ? `${formatSeconds((cue as any).normalizedTime as number)}${(cue as any).timeSource !== 'original' ? ' (estimated)' : ''}`
                    : 'Position: Unknown'}
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${cueTypeColors[cue.type]} rounded-full`}
                      style={{ width: `${(cue as any).normalizedConfidence != null ? ((cue as any).normalizedConfidence as number) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>

                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/0 to-purple-500/0 group-hover:from-blue-500/10 group-hover:to-purple-500/10 transition-all duration-300 pointer-events-none"></div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <p className="text-gray-400 text-sm">
            Cue points are beat-aligned and ready to import into VirtualDJ
          </p>
        </div>
      </div>
    </section>
  );
}
