import { Music, Github, Sparkles } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <div className="flex items-center gap-3 justify-center md:justify-start mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
                AUTOCLUE
              </span>
            </div>
            <p className="text-gray-400 text-sm max-w-md">
              AI-powered DJ cue point generation using GenAI
            </p>
          </div>

          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 px-6 py-3 bg-blue-500/10 border border-blue-500/30 rounded-full">
              <Sparkles className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-blue-400 font-medium">
                Frontend UI Demo Only
              </span>
            </div>
            <p className="text-gray-500 text-sm text-center max-w-md">
              Backend already implemented separately and produces correct outputs
            </p>
          </div>

          <div className="flex flex-col items-center md:items-end gap-4">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl hover:bg-white/10 hover:border-white/20 transition-all duration-300"
            >
              <Github className="w-5 h-5 text-gray-400" />
              <span className="text-gray-300">View on GitHub</span>
            </a>
            <p className="text-gray-500 text-sm">Built with React + TypeScript + Vite</p>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 text-center space-y-3">
          <p className="text-gray-500 text-sm">
            © 2024 AUTOCLUE. Premium AI Music Technology.
          </p>
          <p className="text-gray-600 text-xs">
            Developed by <span className="text-gray-400 font-medium">Tarun R</span> & <span className="text-gray-400 font-medium">Yogapraveen R</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
