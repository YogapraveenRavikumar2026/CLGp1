import { Music, Wand2 } from 'lucide-react';

interface HeroProps {
  onUploadClick: () => void;
  onGenerateClick: () => void;
}

export default function Hero({ onUploadClick, onGenerateClick }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-gray-900 to-black opacity-90"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>

        <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 0.8 }} />
              <stop offset="50%" style={{ stopColor: '#8b5cf6', stopOpacity: 0.8 }} />
              <stop offset="100%" style={{ stopColor: '#3b82f6', stopOpacity: 0.8 }} />
            </linearGradient>
          </defs>
          {[...Array(5)].map((_, i) => (
            <path
              key={i}
              d={`M 0 ${300 + i * 30} Q 250 ${280 + i * 30 + Math.sin(i) * 20} 500 ${300 + i * 30} T 1000 ${300 + i * 30} T 1500 ${300 + i * 30} T 2000 ${300 + i * 30}`}
              stroke="url(#waveGradient)"
              strokeWidth="2"
              fill="none"
              className="animate-wave"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </svg>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <div className="mb-8 inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 backdrop-blur-sm border border-white/10">
          <Music className="w-5 h-5 text-blue-400" />
          <span className="text-sm text-gray-300 font-medium">AI-Powered Music Technology</span>
        </div>

        <h1 className="text-7xl md:text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-blue-400 animate-gradient">
          AUTOCLUE
        </h1>

        <p className="text-2xl md:text-3xl text-gray-300 mb-6 font-light">
          AI-powered DJ Cue Point Generation
        </p>

        <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed">
          Automatically analyze your tracks and generate beat-perfect cue points using advanced
          AI. Transform hours of manual work into seconds of intelligent automation.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={onUploadClick}
            className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-500 rounded-lg font-semibold text-white overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/50 hover:scale-105"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Music className="w-5 h-5" />
              Upload Audio
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>

          <button
            onClick={onGenerateClick}
            className="group relative px-8 py-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg font-semibold text-white overflow-hidden transition-all duration-300 hover:bg-white/10 hover:border-purple-500/50 hover:scale-105"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Wand2 className="w-5 h-5" />
              Generate Cue Points
            </span>
          </button>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-8 max-w-2xl mx-auto">
          {[
            { value: '< 30s', label: 'Processing Time' },
            { value: '99%', label: 'Accuracy' },
            { value: '10x', label: 'Faster' }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
