import { Upload, Waves, Brain, Target, Download } from 'lucide-react';

const steps = [
  {
    icon: Upload,
    title: 'Upload Audio',
    description: 'Drag and drop your track in any format (MP3, WAV, FLAC)'
  },
  {
    icon: Waves,
    title: 'Audio Feature Extraction',
    description: 'Librosa analyzes spectral features, tempo, and rhythm patterns'
  },
  {
    icon: Brain,
    title: 'GenAI Cue Reasoning',
    description: 'Gemini AI intelligently identifies key moments and transitions'
  },
  {
    icon: Target,
    title: 'Beat-aligned Cue Points',
    description: 'Precision-placed markers synced perfectly to the beat grid'
  },
  {
    icon: Download,
    title: 'VirtualDJ Export',
    description: 'Download ready-to-use XML files for instant DJ setup'
  }
];

export default function HowItWorks() {
  return (
    <section className="py-24 px-6 bg-gradient-to-b from-black via-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-4">How It Works</h2>
          <p className="text-xl text-gray-400">Five simple steps to perfect cue points</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 relative">
          <div className="hidden md:block absolute top-1/3 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-blue-500 to-transparent"></div>

          {steps.map((step, index) => (
            <div
              key={index}
              className="relative group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 h-full transition-all duration-300 hover:bg-white/10 hover:border-blue-500/50 hover:scale-105 hover:shadow-lg hover:shadow-blue-500/20">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg border-4 border-gray-900 group-hover:scale-110 transition-transform duration-300">
                  {index + 1}
                </div>

                <div className="mt-8 mb-4 flex justify-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-8 h-8 text-blue-400" />
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-3 text-center">
                  {step.title}
                </h3>
                <p className="text-sm text-gray-400 text-center leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
