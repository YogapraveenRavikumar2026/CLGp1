import { Loader2, Waves, Brain, Target } from 'lucide-react';
import { useEffect, useState } from 'react';

interface ProcessingModalProps {
  isOpen: boolean;
  onComplete: () => void;
}

const stages = [
  { icon: Waves, label: 'Analyzing audio features...', duration: 2000 },
  { icon: Brain, label: 'AI generating cue points...', duration: 2500 },
  { icon: Target, label: 'Aligning to beat grid...', duration: 1500 }
];

export default function ProcessingModal({ isOpen, onComplete }: ProcessingModalProps) {
  const [currentStage, setCurrentStage] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isOpen) {
      setCurrentStage(0);
      setProgress(0);
      return;
    }

    const totalDuration = stages.reduce((sum, stage) => sum + stage.duration, 0);
    let elapsed = 0;

    const interval = setInterval(() => {
      elapsed += 50;
      const newProgress = Math.min((elapsed / totalDuration) * 100, 100);
      setProgress(newProgress);

      let cumulativeDuration = 0;
      for (let i = 0; i < stages.length; i++) {
        cumulativeDuration += stages[i].duration;
        if (elapsed < cumulativeDuration) {
          setCurrentStage(i);
          break;
        }
      }

      if (elapsed >= totalDuration) {
        clearInterval(interval);
        setTimeout(onComplete, 300);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isOpen, onComplete]);

  if (!isOpen) return null;

  const CurrentIcon = stages[currentStage].icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="bg-gray-900 border border-white/10 rounded-3xl p-12 max-w-lg w-full mx-6 shadow-2xl">
        <div className="text-center mb-8">
          <div className="mb-6 flex justify-center">
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-2xl flex items-center justify-center animate-pulse">
                <CurrentIcon className="w-12 h-12 text-blue-400" />
              </div>
              <Loader2 className="absolute -top-2 -right-2 w-8 h-8 text-purple-500 animate-spin" />
            </div>
          </div>

          <h3 className="text-2xl font-bold text-white mb-3">Processing Your Track</h3>
          <p className="text-gray-400 text-lg mb-8">{stages[currentStage].label}</p>

          <div className="relative w-full h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-white/30 animate-shimmer"></div>
            </div>
          </div>

          <div className="mt-4 flex justify-between text-sm text-gray-500">
            <span>Processing...</span>
            <span>{Math.round(progress)}%</span>
          </div>
        </div>

        <div className="space-y-3">
          {stages.map((stage, index) => {
            const StageIcon = stage.icon;
            const isCompleted = currentStage > index;
            const isCurrent = currentStage === index;

            return (
              <div
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                  isCurrent
                    ? 'bg-blue-500/10 border border-blue-500/30'
                    : isCompleted
                    ? 'bg-green-500/10 border border-green-500/30'
                    : 'bg-white/5 border border-white/10'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    isCurrent
                      ? 'bg-blue-500/20'
                      : isCompleted
                      ? 'bg-green-500/20'
                      : 'bg-white/10'
                  }`}
                >
                  <StageIcon
                    className={`w-4 h-4 ${
                      isCurrent
                        ? 'text-blue-400'
                        : isCompleted
                        ? 'text-green-400'
                        : 'text-gray-500'
                    }`}
                  />
                </div>
                <span
                  className={`text-sm ${
                    isCurrent || isCompleted ? 'text-white' : 'text-gray-500'
                  }`}
                >
                  {stage.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
