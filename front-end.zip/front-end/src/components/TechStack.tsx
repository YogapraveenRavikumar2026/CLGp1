import { Code2, Cpu, Binary, Sparkles, FileCode } from 'lucide-react';

const technologies = [
  {
    icon: Code2,
    name: 'Python 3.12',
    description: 'Core backend processing engine',
    color: 'from-blue-500 to-cyan-600'
  },
  {
    icon: Cpu,
    name: 'Librosa',
    description: 'Audio analysis and feature extraction',
    color: 'from-purple-500 to-violet-600'
  },
  {
    icon: Binary,
    name: 'NumPy',
    description: 'High-performance numerical computing',
    color: 'from-green-500 to-emerald-600'
  },
  {
    icon: Sparkles,
    name: 'Gemini GenAI',
    description: 'Intelligent cue point reasoning',
    color: 'from-pink-500 to-rose-600'
  },
  {
    icon: FileCode,
    name: 'VirtualDJ XML',
    description: 'Industry-standard export format',
    color: 'from-orange-500 to-amber-600'
  }
];

export default function TechStack() {
  return (
    <section className="py-24 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-4">Powered By</h2>
          <p className="text-xl text-gray-400">
            Industry-leading technologies for precision results
          </p>
          <div className="mt-6 inline-block px-6 py-3 bg-green-500/10 border border-green-500/30 rounded-full">
            <p className="text-green-400 font-medium">
              ✓ Backend already implemented and functional
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {technologies.map((tech, index) => {
            const Icon = tech.icon;
            return (
              <div
                key={index}
                className="group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative z-10">
                  <div className={`w-16 h-16 bg-gradient-to-br ${tech.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3">{tech.name}</h3>
                  <p className="text-sm text-gray-400 leading-relaxed">{tech.description}</p>
                </div>

                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${tech.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
              </div>
            );
          })}
        </div>

        <div className="mt-16 bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/30 rounded-3xl p-12 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Fully Operational Backend</h3>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed">
            The complete backend processing pipeline has been developed and tested. This frontend
            interface is designed to seamlessly integrate with existing API endpoints for
            production deployment.
          </p>
        </div>
      </div>
    </section>
  );
}
