import { Upload, FileAudio, X } from 'lucide-react';
import { useState } from 'react';

interface UploadSectionProps {
  onGenerate: () => void;
}

export default function UploadSection({ onGenerate }: UploadSectionProps) {
  const [fileName, setFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('audio/')) {
      setFileName(file.name);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleRemove = () => {
    setFileName(null);
  };

  return (
    <section id="upload" className="py-24 px-6 bg-black">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold text-white mb-4">Upload Your Track</h2>
          <p className="text-xl text-gray-400">
            Drag and drop or click to select your audio file
          </p>
        </div>

        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-3xl p-12 transition-all duration-300 ${
            isDragging
              ? 'border-blue-500 bg-blue-500/10'
              : 'border-white/20 bg-white/5 backdrop-blur-sm hover:border-blue-500/50 hover:bg-white/10'
          }`}
        >
          <input
            type="file"
            accept="audio/*"
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />

          {!fileName ? (
            <div className="text-center">
              <div className="mb-6 flex justify-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-2xl flex items-center justify-center">
                  <Upload className="w-10 h-10 text-blue-400" />
                </div>
              </div>
              <h3 className="text-2xl font-semibold text-white mb-3">
                Drop your audio file here
              </h3>
              <p className="text-gray-400 mb-6">or click to browse</p>
              <p className="text-sm text-gray-500">
                Supports MP3, WAV, FLAC, AAC, OGG • Max 100MB
              </p>
            </div>
          ) : (
            <div className="flex items-center justify-between bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileAudio className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">{fileName}</p>
                  <p className="text-sm text-gray-400">Ready to process</p>
                </div>
              </div>
              <button
                onClick={handleRemove}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-400 hover:text-white" />
              </button>
            </div>
          )}
        </div>

        {fileName && (
          <div className="mt-8 text-center">
            <button
              onClick={onGenerate}
              className="group relative px-12 py-5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-semibold text-white text-lg overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/50 hover:scale-105"
            >
              <span className="relative z-10 flex items-center gap-3">
                <FileAudio className="w-6 h-6" />
                Generate Cue Points
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
