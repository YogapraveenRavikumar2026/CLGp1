export interface CuePoint {
  id: string;
  label: string;
  timestamp: string;
  timeInSeconds: number;
  type: 'intro' | 'verse' | 'buildup' | 'drop' | 'chorus' | 'breakdown' | 'outro';
  confidence: number;
}

export const mockCuePoints: CuePoint[] = [
  {
    id: '1',
    label: 'Intro',
    timestamp: '0:00',
    timeInSeconds: 0,
    type: 'intro',
    confidence: 0.98
  },
  {
    id: '2',
    label: 'Verse 1',
    timestamp: '0:32',
    timeInSeconds: 32,
    type: 'verse',
    confidence: 0.95
  },
  {
    id: '3',
    label: 'Build-up',
    timestamp: '1:04',
    timeInSeconds: 64,
    type: 'buildup',
    confidence: 0.92
  },
  {
    id: '4',
    label: 'Drop',
    timestamp: '1:28',
    timeInSeconds: 88,
    type: 'drop',
    confidence: 0.99
  },
  {
    id: '5',
    label: 'Chorus',
    timestamp: '1:44',
    timeInSeconds: 104,
    type: 'chorus',
    confidence: 0.96
  },
  {
    id: '6',
    label: 'Breakdown',
    timestamp: '2:16',
    timeInSeconds: 136,
    type: 'breakdown',
    confidence: 0.94
  },
  {
    id: '7',
    label: 'Build-up 2',
    timestamp: '2:48',
    timeInSeconds: 168,
    type: 'buildup',
    confidence: 0.93
  },
  {
    id: '8',
    label: 'Drop 2',
    timestamp: '3:12',
    timeInSeconds: 192,
    type: 'drop',
    confidence: 0.97
  },
  {
    id: '9',
    label: 'Outro',
    timestamp: '3:44',
    timeInSeconds: 224,
    type: 'outro',
    confidence: 0.95
  }
];

export const mockTrackInfo = {
  fileName: 'summer_vibes_mix.mp3',
  duration: '4:12',
  bpm: 128,
  key: 'A minor'
};
